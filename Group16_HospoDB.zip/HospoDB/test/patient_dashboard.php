<?php
echo "patient screen";


?>