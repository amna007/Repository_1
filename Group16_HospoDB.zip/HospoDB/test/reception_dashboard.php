<?php
echo "Reception screen";


?>