<?php

    $name=$_GET['name'];
    $gender = $_GET['gender'];
    $age = $_GET['age'];
    $phone_no = $_GET['phone_no'];
    $company_email = $_GET['company_email'];
    $department = $_GET['department'];
    $office_no = $_GET['office_no'];
    $rank = $_GET['rank'];
    $login = $_GET['login'];
    $working_hours = $_GET['working_hours'];
    $salary = $_GET['salary'];
    $charges = $_GET['charges'];


    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'hospodb';

    $conn = mysqli_connect($servername, $username, $password, $dbname);


    if ($conn==false) {
        echo "Connection Failed";
    }
    else{
        echo "Connection successful";
    }
    
    //do anything to the database, you have access
 
    $sql = "INSERT INTO `doctor` (`name`, `gender`, `age`, `phone_number`, `department_name`, `office_number`, `password`, `rank`, `salary`, `time_slot_ID`, `email`, `bill_charges`)  VALUES ('$name','$gender', $age , $phone_no,'$department', $office_no, '$login','$rank',$salary,$working_hours, '$company_email', $charges)";
    $sql1 = "SELECT `doctor_ID` FROM `doctor` WHERE `email`='$company_email'";
    $result = mysqli_query($conn,$sql1);
    if (mysqli_num_rows($result)==0) {
        echo "Email is available";
        if (mysqli_query($conn, $sql)) {
            echo "Query Successful";
        } else {
            echo "Query failed";
        }
    } else {
        header('Location:doctor_form.php?emailNotAvailable=1');
    }
    

    mysqli_close($conn);




?>
